#!/usr/bin/env python
# -*- coding: utf-8 -*-
# import pwndbg.arch
# import pwndbg.jump.mips
# import pwndbg.jump.arm
# import pwndbg.jump.ppc
# import pwndbg.jump.x86
# import pwndbg.jump.sparc

# def get_target(pc):
#     return {
#         'i386': pwndbg.jump.x86.resolver,
#         'x86-64': pwndbg.jump.x86.resolver
#     }.get(pwndbg.arch.current, lambda *a: None)(pc)

# class Foo(object):
#     @property
#     def foobar(self):
#         return self._foobar
