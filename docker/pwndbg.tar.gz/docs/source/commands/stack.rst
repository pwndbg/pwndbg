.. autoprogram:: pwndbg.commands.stack:p
   :prog: stack
