.. autoprogram:: pwndbg.commands.search:parser
   :prog: search
