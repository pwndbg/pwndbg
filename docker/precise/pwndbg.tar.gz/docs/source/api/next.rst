:mod:`pwndbg.next` --- pwndbg.next
=============================================

.. automodule:: pwndbg.next
    :members:
